f = lambda x: x*x

r = f(10)

print (r)
