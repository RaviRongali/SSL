
h = lambda f,x: f(x)

def f(p):
	return (p*p)

r = h(f,9)

print (r)
