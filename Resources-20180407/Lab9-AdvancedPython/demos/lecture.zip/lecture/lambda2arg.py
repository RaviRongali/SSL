
f = lambda x,y: x**y

r = f(7,2)

print (r)
