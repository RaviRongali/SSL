l = [1,2,1,3,4,4,2]
print (l)

s = set (l)

print (s)
