def f(result,x,N=7):
	if (x==N): return result+1;
	else: return result;
	

def countN (l):
	return reduce (f, l) 


mylist = [0,1,7,2,3,4,5,6,7,8,7,7]

print mylist
print countN (mylist)



