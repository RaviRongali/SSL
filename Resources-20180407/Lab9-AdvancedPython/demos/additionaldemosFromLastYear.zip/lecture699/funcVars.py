f =  lambda g, x: g (x) 

def sq (p) : return p*p

print  f(sq,10)
