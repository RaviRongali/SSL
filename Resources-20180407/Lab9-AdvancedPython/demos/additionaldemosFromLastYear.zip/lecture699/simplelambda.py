f =  lambda g, x: g (x) 

x = def sq (p) : return p*p

print  f(x,10)
