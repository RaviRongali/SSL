s = set (['a','b','c','a','d','a','bat','e','f'])

s = {1,2,3} | s

s.add('good')

print s;


print 'a' in s


print 'b' not in s 


print len(s)
