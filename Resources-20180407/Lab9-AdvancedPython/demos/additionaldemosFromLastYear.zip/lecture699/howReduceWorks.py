def f(x,y):
	print x, y
	return -1

def sumall (l):
	return reduce (f, l) 


mylist = [1,2,3,4,5,6,7]

print mylist
print sumall (mylist)



