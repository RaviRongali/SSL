def pickeven (l):
	return filter (lambda x: x%2 == 0, l) 


mylist = [1,2,3,4,5,6,7]

print pickeven (mylist)



