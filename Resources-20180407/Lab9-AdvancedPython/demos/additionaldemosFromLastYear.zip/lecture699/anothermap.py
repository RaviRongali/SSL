def f (x) : return x*x

def squareall (l):
	result = []
	return ( map (f, l) )


mylist = [1,2,3,4]

sqlist = squareall (mylist)


print sqlist

sqlist.append(100)

print sqlist
print len(sqlist)


