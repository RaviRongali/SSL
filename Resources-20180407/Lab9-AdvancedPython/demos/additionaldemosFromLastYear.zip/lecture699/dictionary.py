mydict = { 'vipin': 100, 'vipul' : 28, 'jeevan':12, 'imad':50 }

print mydict

print mydict['vipin']

print mydict.has_key('imad')

print mydict.items()

print mydict.items()[0]
print mydict.items()[0][1]

del mydict['vipin']

mydict['saki']=200

print mydict.values()
print mydict.keys()

print mydict
