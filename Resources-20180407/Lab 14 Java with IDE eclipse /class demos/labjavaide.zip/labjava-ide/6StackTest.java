import java.util.*;


class StackTest {




 public static void main (String args[]) {


   Stack <Integer> c = new Stack<Integer> (); 

	c.push(10);
	c.push(20);
	System.out.println(c.peek()); 
	System.out.println(c.pop()); 
	System.out.println(c.pop()); 

 }


}
