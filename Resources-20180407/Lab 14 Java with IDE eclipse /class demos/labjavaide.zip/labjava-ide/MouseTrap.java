// how mouse events are trapped through observation by event listeners

import java.awt.*;
import java.applet.*;
import java.lang.*;
import java.awt.event.*;

// height=300, width=300 

public class MouseTrap extends Applet 
		implements MouseListener, MouseMotionListener {

	private int x,y, x1, y1;
	private int count;
	

	public void init () {
		setBackground (Color.cyan);
		x=y=0;
		count = 0;
		addMouseListener (this);
		addMouseMotionListener (this);
	}
	public void paint (Graphics g) {
		g.drawLine (0,0,300,300);
		g.drawString ("Mouse event count:" + count + "  ",100,100);
		g.drawString ("Mouse last clicked at:" + x + "," + y, 100,150);
		showStatus ("Applet Working!");
	}
   
	public void mouseClicked (MouseEvent e) {
		count=count+1;
		x=e.getX();
		y=e.getY();
		repaint();		
	}	

	public void mouseEntered (MouseEvent e){	
		count=count+2;
		repaint();		
	}
	public void mousePressed (MouseEvent e){	
		count=count+4;	
		repaint();		
	}
	public void mouseReleased (MouseEvent e){	
		count=count+8;
		repaint();		
	}
	public void mouseExited (MouseEvent e){	
		count=count+16;
		repaint();		
	}


	public void mouseDragged (MouseEvent e) {

	}

	public void mouseMoved (MouseEvent e) {

	}
	
}


