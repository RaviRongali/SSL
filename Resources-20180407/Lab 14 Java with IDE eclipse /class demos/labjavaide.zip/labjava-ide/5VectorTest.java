//using vectors
import java.util.*;

class VectorTest {

	public static void main (String args[]) {

		Vector<Integer>  v=new Vector<Integer>();	
		System.out.println ("Vector now has " + v.size() + " elements");
		v.addElement(20);
		v.addElement(30);

		System.out.println (v.get(1));


	}	

}

