def make_list():
	#Code to process the input file and return a list l
	#return l
	pass

def column_collapse(L):
	#Code to search the number x in l.
	#print the number of steps taken to reach x
	#return collapsed_list
	pass
