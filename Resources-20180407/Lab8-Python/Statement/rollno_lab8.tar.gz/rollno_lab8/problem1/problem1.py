def make_list():
	#Code to process the input file and return a list l
	#return l
	pass

def mysort(l):
	#Code to sort the file should be written here.
	#Print the sorted list.
	#return l
	pass
