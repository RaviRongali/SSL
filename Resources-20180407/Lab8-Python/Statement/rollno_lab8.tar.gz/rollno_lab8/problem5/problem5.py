def make_list():
        #Code to process the input file and return a list of list L
        #return L
        pass

def freqcount(L):
	#freqcount() takes list of lists and saves each distint string with the count into a dictionary 
	#return dictionary
	pass

