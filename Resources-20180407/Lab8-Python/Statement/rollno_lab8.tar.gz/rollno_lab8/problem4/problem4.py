def make_list():
        #Code to process the input file and return a list of list L
        #return L
        pass

def det(L):
	#Code to get the determinant of the matrix
	#Print the value of the derterminant.
	#return determinant
	pass
