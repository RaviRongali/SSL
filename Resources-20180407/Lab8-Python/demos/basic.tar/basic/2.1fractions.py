from fractions import Fraction

x = Fraction (2,3)
y = Fraction (3,4)
print x+y
