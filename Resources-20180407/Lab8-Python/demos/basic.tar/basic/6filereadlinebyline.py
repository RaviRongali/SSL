import sys
f = open (sys.argv[1])
for l in f: print l
