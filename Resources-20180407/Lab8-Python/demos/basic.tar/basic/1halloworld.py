print "hallo world!"
