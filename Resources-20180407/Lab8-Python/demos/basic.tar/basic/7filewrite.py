import sys

f=open(sys.argv[1],'w')
for i in range(1,100):
  f.write(str(i)+'\n')
  print "hallo" 
	
