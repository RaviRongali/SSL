a,b=0,1
i=0
while i<10:
	print (b)
	a,b=b,a+b
	i=i+1


