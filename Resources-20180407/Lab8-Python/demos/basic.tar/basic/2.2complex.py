e=1+2j
f=7+8j
g=e+f
print g

h=e*f

print h

print h.real
print h.imag


