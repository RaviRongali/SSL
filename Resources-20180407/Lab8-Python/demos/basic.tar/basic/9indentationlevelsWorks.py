
for i in range(1,100):
  print i
  print "hallo"
	
