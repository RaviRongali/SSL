l1 = [1, 2, 3, "hallo", 5, 6]
l2 = l1;
l2[1]=0  #shallow copy
print (l1)
print (l2)


