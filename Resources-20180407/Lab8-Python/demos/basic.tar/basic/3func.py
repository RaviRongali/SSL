import math

def func (x,y): 
	p= x*x 
	q= y*y
	r=math.sqrt(p+q)
	return r

x = func(3,4)
print x
