#use python3.4 
a = 10
b = 20
c = a+b
print (c)
d = 2 ** 3
print (d)

e = -5 / 3     
print (e)

f = -5 // 3   
print (f)


#good read:
#https://www.python.org/dev/peps/pep-0238/ which discusses some problems

# Floating Point Arithmetic: Issues and Limitations
# https://docs.python.org/3/tutorial/floatingpoint.html
# discusses some of the issues

